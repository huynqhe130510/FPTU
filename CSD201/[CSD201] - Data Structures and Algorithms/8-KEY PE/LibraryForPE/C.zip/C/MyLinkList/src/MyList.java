
public class MyList {

    //a list of Nodes
    Node<Color> head, tail;

    //ctor
    public MyList() {
        head = tail = null;
    }

    //1. return true if list is empty otherwise return false
    public boolean isEmpty() {
        return head == null;
    }

    //2. insertion: insert a Color to the end of list O(1)
    public void addLast(Color c) {
        Node<Color> p = new Node(c);
        if (isEmpty()) {
            head = tail = p;
        } else {
            tail.next = p;
            tail = p;
        }
    }

    //3. insertion: insert a Color to the beginning of list  O(1)
    public void addFist(Color c) {
        Node<Color> p = new Node(c);
        if (isEmpty()) {
            head = tail = p;
        } else {
            p.next = head;
            head = p;
        }
    }

    //4. traversal a list 
    public void traversal() {
        Node<Color> p = head;
        while (p != null) {
            System.out.println(p.info);
            p = p.next;
        }
    }

    //5. remove a Node at position k, starting position is 0; O(n)
    public void remove(int k) {
        if (isEmpty()) {
            return;
        }
        if (k == 0) {
            Node<Color> p = head;
            head = head.next;
            p.next = null;
        } else {
            Node<Color> p = getNode(k);
            if (p == null) {
                return;
            }
            Node<Color> q = getNode(k - 1);
            //remove p
            q.next = p.next;
            p.next = null;
            if (p == tail) {
                tail = q;
            }
        }
    }

    void remove(Node p){
        if(p == null || isEmpty()) return;
        Node f = null, q = head;
        //find the a node before p
        while(q != null && q != p){
            f = q; q = q.next;
        }
        if(f == null){// remove head
            head = head.next;
            if(head == null) tail = null;
        }else {
            f.next = p.next;
            if(p == tail) tail = f;
        }
    }
    //6. get a Node at position k
    public Node<Color> getNode(int k) {
        int c = 0;
        Node<Color> p = head;
        while (c < k && p != null) {
            p = p.next;
            c++;
        }
        return p;
    }

    //7. count number of nodes in the list
    public int size() {
        int c = 0;
        Node<Color> p = head;
        while (p != null) {
            p = p.next;
            c++;
        }
        return c;
    }

    //8. reverse the list
    public void reverse() {
        int n = size(), i, j;
        for (i = 0, j = n - 1; i < j; i++, j--) {
            Node<Color> pi = getNode(i);
            Node<Color> pj = getNode(j);
            Color temp = pi.info;
            pi.info = pj.info;
            pj.info = temp;
        }
    }

    //9. sort the list ascending by color value
    public void sort() {
        Node<Color> pi, pj;
        pi = head;
        int c =0;
        while (pi != null) {

            pj = pi.next;
            while (pj != null) {
                if (pi.info.value > pj.info.value) {
                    Color temp = pi.info;
                    pi.info = pj.info;
                    pj.info = temp;
                    c++;
                    if (c == 3) return;

                }
                pj = pj.next;
            }
            pi = pi.next;
        }
     
    }

    public void sort1() {
        for (int i = 0; i < size() - 1; i++) {
            for (int j = i + 1; j < size(); j++) {

                Node<Color> pi = getNode(i);
                Node<Color> pj = getNode(j);
                if (pi.info.value > pj.info.value) {
                    Color temp = pi.info;
                    pi.info = pj.info;
                    pj.info = temp;

                }
            }
        }
    }

    //10. remove the second biggest color value in the list
    public void removeSecond() {
        Color firstMax = getMaxColor();
        if (firstMax == null) {
            return;
        }
        if (size() <= 1) {
            return;
        }
        int imax = 0;
        Node<Color> p = head;
        while (p != null && p.info.value == firstMax.value) {
            imax++;
            p = p.next;
        }
        //find second max starting from imax
        Color secondMax = (p != null) ? p.info : null;
        for (int i = 0; i < size() - 1; i++) {
            if (getNode(i).info.value > secondMax.value && getNode(i).info.value != firstMax.value) {
                imax = i;
                secondMax = getNode(i).info;
            }
        }
        if (imax < size()) {
            remove(imax);
        }
    }

    //11. search: return the first Node which color name = given color name - 
    // return null if given color name does not exists in the list
    public Node<Color> search(String colorName) {
        Node<Color> p = head;
        while (p != null) {
            if (p.info.name.equalsIgnoreCase(colorName)) {
                break;
            }
            p = p.next;
        }

        return p;
    }

    //0. helper: return the first biggest color value node in the list 
    public Color getMaxColor() {
        if (isEmpty()) {
            return null;
        }
        Color max = head.info;
        Node<Color> p = head;
        while (p != null) {
            if (p.info.value > max.value) {
                max = p.info;
            }
            p = p.next;
        }
        return max;
    }
    
    public Node getMax() {
        if (isEmpty()) {
            return null;
        }
        Node max = head;
        Node p = head;
        while (p != null) {
            if (p.info.equals(max.info)) {
                max = p;
            }
            p = p.next;
        }
        return max;
    }

}
