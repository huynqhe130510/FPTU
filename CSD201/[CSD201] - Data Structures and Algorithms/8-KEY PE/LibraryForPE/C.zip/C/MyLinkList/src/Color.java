
public class Color {
    String name;
    int value;

    public Color() {
    }

    public Color(String name, int value) {
        this.name = name;
        this.value = value;
    }

    @Override
    public String toString() {
        return "(" + name + ", " + value + ")";
    }
    
}
