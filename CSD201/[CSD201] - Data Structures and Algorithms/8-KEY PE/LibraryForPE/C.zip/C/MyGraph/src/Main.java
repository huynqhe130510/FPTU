
public class Main {
    
    public static void main(String[] args) {
        
//        Graph g = new Graph();
//        g.bfs();
//        System.out.println("");
//        g.dfs();
//        System.out.println("");
//        //a path from B to H
//        g.u = 1;//B
//        g.v = 4;//E
//        g.path();
//        System.out.println("");
//        g.connectivity();
//          MyDijkstra m = new MyDijkstra();
//          m.ijk(0, 5);//from A to F
//          System.out.println("");
           MyEuler m = new MyEuler();
           m.euler();
    }
}
