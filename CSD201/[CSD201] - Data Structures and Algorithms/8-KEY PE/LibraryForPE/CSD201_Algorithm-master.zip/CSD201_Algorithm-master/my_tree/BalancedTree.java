/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my_tree;

/*  BALANCED TREE 
    + Balanced factor of p = height(p.right) - height(p.left)

    + ==> Balanced tree is tree that all node has balanced factor i (-1, 0, 1)

*/
public class BalancedTree {
    
    
}
