﻿// shapeslib.cs
using System;

namespace MyShapes
{
     // Circle class.
     public class Circle{  /* Interesting methods... */ } 
     // Hexagon class.
     public class Hexagon{ /* More interesting methods... */ } 
     // Square class.
     public class Square{  /* Even more interesting methods... */ } 
} 
