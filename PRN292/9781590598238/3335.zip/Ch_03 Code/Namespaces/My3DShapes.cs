﻿// Another shapes namespace...
using System;

namespace Chapter3
{
    namespace My3DShapes
    {
        // 3D Circle class.
        class Circle { }
        // 3D Hexagon class
        class Hexagon { }
        // 3D Square class
        class Square { }
    }
}

