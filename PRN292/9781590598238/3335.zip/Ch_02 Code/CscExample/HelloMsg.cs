// The HelloMessage Class
using System;
using System.Windows.Forms;

class HelloMessage
{
    public void Speak()
    { MessageBox.Show("Hello..."); }
}
