using System;

// This type will be placed
// within a *.netmodule binary,
// and it thus part of a multifile
// assembly. 
namespace AirVehicles
{
	public class Ufo
	{
		public void AbductHuman()
		{
			Console.WriteLine("Resistance is futile");
		}
	}
}