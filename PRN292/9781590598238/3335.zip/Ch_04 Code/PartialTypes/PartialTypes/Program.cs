using System;
using System.Collections.Generic;
using System.Text;

namespace PartialTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***** Fun with Partial Types *****");
            Console.WriteLine("See code for details...");
            Console.ReadLine();
        }
    }
}
