using System;
using System.Collections.Generic;
using System.Text;

namespace TestNamespace
{
    class JustATest
    {
        void SomeMethod()
        {
            // Error!  Need to use the MyUtilities namespace!
            //int i = 0;
            //i.Foo();
        }
    }
}
