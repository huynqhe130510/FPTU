package q1_23_3_2018;

public class DessertItem {
    String name;

    public DessertItem() {
    }

    public DessertItem(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.name; //To change body of generated methods, choose Tools | Templates.
    }
    
        
}
