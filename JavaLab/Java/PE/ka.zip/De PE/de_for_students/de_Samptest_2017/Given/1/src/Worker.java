
public class Worker extends Person{  
    
    public Worker(String name, int salary, String deptName) { 
        super(name);
        //your code goes here     
    }  
    /*Complete the below function for second test case*/
    public int getSalary() {
        throw new UnsupportedOperationException(
                "Remove this line and implement your code here!");
    }  
    //add and complete your other methods here (if needed)
 
}
