public class Person {
  
    public Person(String name) {
      throw new UnsupportedOperationException(
                "Remove this line and implement your code here!");
    }    
   //add and complete your other methods here (if needed)   
}
