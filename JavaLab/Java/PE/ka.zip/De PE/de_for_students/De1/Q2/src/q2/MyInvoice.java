
import java.util.*;
//Your task is to complete this class 

public class MyInvoice implements IInvoice {

    //write the definition of method f1 here 
    @Override
    public String f1(ArrayList<Invoice> a) {
        
    }

    //write the definition of method f2 here 
    @Override
    public int f2(ArrayList<Invoice> a) {
        
    }
    //add and complete you other methods (if needed) here   
}
