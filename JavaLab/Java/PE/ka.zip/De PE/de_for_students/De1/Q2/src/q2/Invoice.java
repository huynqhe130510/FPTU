//your job is to complete this class
public class Invoice {   
    String name;
    int amount;

    
    
    
    
}