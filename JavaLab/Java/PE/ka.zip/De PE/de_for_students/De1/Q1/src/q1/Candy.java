
import static java.lang.Math.ceil;
import static java.lang.Math.floor;

public class Candy extends DessertItem {

    

    @Override
    public String toString() {
        return name + " " + price + " " + weight;
    }

    public double getCost() {
        
    }

}
