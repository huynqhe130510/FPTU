public class DessertItem {
    
        String name;

    ......
    }
        
        
}
