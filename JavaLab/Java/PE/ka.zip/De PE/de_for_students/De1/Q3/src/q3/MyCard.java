package q3;


import static java.lang.Character.isDigit;


public class MyCard {

    String cardNumber;
    String typeNumber;

    

    public MyCard(String typeNumber,String cardNumber) {
        
    }

   

    public String getCardCode() {
       
        
    }
}
