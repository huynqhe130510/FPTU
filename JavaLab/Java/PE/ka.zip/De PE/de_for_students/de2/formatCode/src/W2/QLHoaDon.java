/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package W2;
import java.io.*;
import java.util.*;
import java.util.ArrayList;

/**
 *
 * @author Kudo
 */
public class QLHoaDon implements IHOADON{

    @Override
    public void f1(ArrayList<HoaDon> a) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter number of Invoice: ");
       int n = Integer.parseInt(in.readLine());
      
       
       }
   }

    @Override
    public void f2(ArrayList<HoaDon> a) {
       
        }
 }
    
}
