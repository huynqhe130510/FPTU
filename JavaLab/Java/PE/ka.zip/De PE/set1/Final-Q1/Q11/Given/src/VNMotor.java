
public class VNMotor extends Motor{  
    
    public VNMotor() {
       throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    public VNMotor(String brandName, String series, double price) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
        
    }
    
    /*Complete the below function for second test case*/
    public double getSalePrice() {
       throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }  
    
    //add and complete your other methods here (if needed)

}
