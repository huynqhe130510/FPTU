
public class Motor {
 
    public Motor() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    
    public Motor(String brandName, double price) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }    
    
    
}
