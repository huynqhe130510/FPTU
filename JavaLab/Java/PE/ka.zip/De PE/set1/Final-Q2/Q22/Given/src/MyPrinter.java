

 
import java.util.*;

public class MyPrinter implements IPrinter { 

    @Override
    public void f1(List<Printer> a, double price) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    

    @Override
    public int f2(List<Printer> a, String name) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

   
    
    
     
}
