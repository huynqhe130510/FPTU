
public class Printer {   
     
    public Printer() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    
    public Printer(String name, double price) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }


    public String getName() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    //add and complete you other methods (if needed) here   
 
}
