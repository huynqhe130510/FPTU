public class ReservationCode {
    
    public ReservationCode(String code, String customerName) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    
     
    String getCode() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!"); 
    }
    
    /*add and complete your other methods here (if needed)*/
    
}
