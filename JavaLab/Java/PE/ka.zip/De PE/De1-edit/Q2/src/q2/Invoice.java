//your job is to complete this class
package q2;
public class Invoice {   
    String name;
    int amount;

    public Invoice() {
    }

    public Invoice(String name, int amount) {
        this.name = name;
        this.amount = amount;
    } 
}