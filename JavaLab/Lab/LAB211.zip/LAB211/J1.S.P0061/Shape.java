
/**
 *
 * @author THAYCACAC
 */
public abstract class Shape {

    public double getPerimeter() {
        return 0;
    }

    public double getArea() {
        return 0;
    }

    public void printResult() {
    }
}
