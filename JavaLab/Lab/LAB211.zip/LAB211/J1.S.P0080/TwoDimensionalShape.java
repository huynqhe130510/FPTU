/**
 *
 * @author THAYCACAC
 */
public class TwoDimensionalShape extends Shape{

    @Override
    double getArea() {
        return super.getArea();
    }
}
