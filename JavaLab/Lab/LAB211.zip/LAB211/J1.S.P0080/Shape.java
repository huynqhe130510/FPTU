
/**
 *
 * @author THAYCACAC
 */
public class Shape {

    public Shape() {
    }

    double getArea() {
        return 0;
    }

    double getVolume() {
        return 0;
    }
}
