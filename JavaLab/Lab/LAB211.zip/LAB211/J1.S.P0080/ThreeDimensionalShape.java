/**
 *
 * @author THAYCACAC
 */
public class ThreeDimensionalShape extends Shape{

    @Override
    double getArea() {
        return 0;
    }
    
    double getVolume(){
        return 0;
    }
    
}
