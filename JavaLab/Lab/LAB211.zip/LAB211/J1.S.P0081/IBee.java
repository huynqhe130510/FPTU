
public interface IBee {

    public void creatBeeList();

    public void damage();
}
